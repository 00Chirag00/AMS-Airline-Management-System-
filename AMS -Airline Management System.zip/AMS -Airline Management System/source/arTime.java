//class to convert time format
//created by Chirag
package source;

import java.util.*;
public class arTime
{
	public Calendar a;
	arTime()
	{
		a = Calendar.getInstance();
	}
	
	public Calendar getA()
	{
		return a;
	}
	
}